import os
from CustomHash import encrypt,decrypt,create_key
from flask import current_app as app
from werkzeug.utils import secure_filename
import  database as db
import hashlib
import  uuid

def create_tag(data):
    tag = hashlib.sha512(hashlib.sha512(data).hexdigest().encode("ascii")).hexdigest()
    return tag
def write_to_file(text,filename):
    file = open(filename,"w")
    file.write(text)
    file.close()

def upload(data,filename):
    filename =  "uploads" + "/" + secure_filename(filename)
    tag = create_tag(data)
    created = False
    duplicated,id = check_duplication(tag)
    key = None
    if not duplicated :
        key = create_key()
        enc_text = encrypt(data, key)
        write_to_file(enc_text,filename)
        q = "insert into file(`file_path`,`date`,`status`,`key`,`tag`)values('%s',curdate(),'%s','%s','%s')" %(filename,'active',key,tag)
        print(q)
        id = db.insert(q)
        created = True
    return created,id


def download(file_id):
    q = "select * from file where file_id = '%s'" % file_id
    res = db.select(q)
    key = res[0]['key']
    file = open(res[0]['file_path'],"r")
    data= file.read()
    data = decrypt(data,key)
    # file1 = open("static/temp/" + os.path.basename(res[0]['file_path']),"w" )
    # file1.write(data)
    # file1.close()
    # file.close()
    # return "static/temp/" + os.path.basename(res[0]['file_path'])
    return data, os.path.basename(res[0]['file_path'])

def check_duplication(tag):
    q = "select * from file where tag='%s'" % tag
    res = db.select(q)
    if(len(res) > 0):
        return True,res[0]['file_id']
    else:
        return False,None


def delete(file_id):
    q = "select * from  files where file_id='%s'" % file_id
    res = db.select(q)
    file_path = res['file_path']
    os.remove(file_path)
    q = "delete from files where file_id='%s'" % file_id
    db.delete(q)




